#ifndef __DELAY_H_
#define __DELAY_H_

#define delayms Delayms
#define delayus Delayus
void Delayms(unsigned int t);  //@11.0592MHz
void Delayus(unsigned int t);

#endif