#ifndef __DELAY_H_
#define __DELAY_H_

//void Delay100us();		//@11.0592MHz
void Delayms(unsigned int t);
void Delayus(unsigned int t);
#endif