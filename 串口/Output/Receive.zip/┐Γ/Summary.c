//延迟
#ifndef __DELAY_H_
#define __DELAY_H_
void Delayms(unsigned int t);
void Delayus(unsigned int t);
#endif
#include "Delay.h"
#include "intrins.h"
void Delayms(unsigned int t)  //@11.0592MHz
{
  unsigned char i, j;
  while (t--) {
    _nop_();
    i = 11;
    j = 185;
    do {
      while (--j)
        ;
    } while (--i);
  }
}
void Delayus(unsigned int t)  //@11.0592MHzŃÓłŮtÎ˘Ăë
{
  while (t--) _nop_();
}

// I2C
#ifndef _I2C_H_
#define _I2C_H_
#include <reg52.h>
#include <intrins.h>
extern bit ack;
void Start_I2c();
void Stop_I2c();
void Ack_I2c(bit a);
void SendByte(unsigned char c);
bit ISendStr(unsigned char sla, unsigned char suba, unsigned char *s,
             unsigned char no);
bit ISendStrExt(unsigned char sla, unsigned char *s, unsigned char no);
unsigned char RcvByte();
#endif

#include "i2c.h"
#define NOP() _nop_()
#define _Nop() _nop_()
sbit SCL = P2 ^ 0;
sbit SDA = P2 ^ 1;
bit ack;
void Start_I2c() {
  SDA = 1;
  _Nop();
  SCL = 1;
  _Nop();
  _Nop();
  _Nop();
  _Nop();
  _Nop();
  SDA = 0;
  _Nop();
  _Nop();
  _Nop();
  _Nop();
  _Nop();
  SCL = 0;
  _Nop();
  _Nop();
}
void Stop_I2c() {
  SDA = 0;
  _Nop();
  SCL = 1;
  _Nop();
  _Nop();
  _Nop();
  _Nop();
  _Nop();
  SDA = 1;
  _Nop();
  _Nop();
  _Nop();
  _Nop();
}
void SendByte(unsigned char c) {
  unsigned char BitCnt;

  for (BitCnt = 0; BitCnt < 8; BitCnt++) {
    if ((c << BitCnt) & 0x80)
      SDA = 1;
    else
      SDA = 0;
    _Nop();
    SCL = 1;
    _Nop();
    _Nop();
    _Nop();
    _Nop();
    _Nop();
    SCL = 0;
  }

  _Nop();
  _Nop();
  SDA = 1;
  _Nop();
  _Nop();
  SCL = 1;
  _Nop();
  _Nop();
  _Nop();
  if (SDA == 1)
    ack = 0;
  else
    ack = 1;
  SCL = 0;
  _Nop();
  _Nop();
}
unsigned char RcvByte() {
  unsigned char retc;
  unsigned char BitCnt;

  retc = 0;
  SDA = 1;
  for (BitCnt = 0; BitCnt < 8; BitCnt++) {
    _Nop();
    SCL = 0;
    _Nop();
    _Nop();
    _Nop();
    _Nop();
    _Nop();
    SCL = 1;
    _Nop();
    _Nop();
    retc = retc << 1;
    if (SDA == 1) retc = retc + 1;
    _Nop();
    _Nop();
  }
  SCL = 0;
  _Nop();
  _Nop();
  return (retc);
}
void Ack_I2c(bit a) {
  if (a == 0)
    SDA = 0;
  else
    SDA = 1;
  _Nop();
  _Nop();
  _Nop();
  SCL = 1;
  _Nop();
  _Nop();
  _Nop();
  _Nop();
  _Nop();
  SCL = 0;
  _Nop();
  _Nop();
}
