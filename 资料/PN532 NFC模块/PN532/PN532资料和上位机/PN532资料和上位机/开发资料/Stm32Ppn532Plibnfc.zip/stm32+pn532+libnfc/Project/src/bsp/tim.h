#ifndef __TIM_H__
#define __TIM_H__
#include "stm32f10x.h"

extern volatile uint32_t gTimerDrvTicks;

uint32_t TimerDrvGetTicks();
uint8_t TimerDrvGetDly(uint32_t TicksHome, uint32_t TicksDly);

#endif
