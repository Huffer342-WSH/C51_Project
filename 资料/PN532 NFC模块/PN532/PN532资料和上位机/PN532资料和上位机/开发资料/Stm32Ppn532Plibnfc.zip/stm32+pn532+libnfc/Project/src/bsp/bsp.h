#ifndef __BSP_H__
#define __BSP_H__
#include "stm32f10x.h"

void BSP_Init(void);


#endif
