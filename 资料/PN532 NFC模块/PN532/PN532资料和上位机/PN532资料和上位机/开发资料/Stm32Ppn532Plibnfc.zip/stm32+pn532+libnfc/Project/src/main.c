#include <stdio.h>
#include "bsp.h"
#include "emdev.h"
#include "tim.h"


#ifdef __GNUC__
 
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

void initiator();
void target();
int list_passive_targets();
int emulate_tag();

nfc_emdev emdev;

int main(void)
{
  BSP_Init();
  emdev_init(&emdev);
//  emulate_tag();
  while(1)
  {
   initiator();
//   target(); 
#if 0  
    list_passive_targets();
#endif
    uint32_t ticks1 = TimerDrvGetTicks();
    while(!TimerDrvGetDly(ticks1, 2000));
  }
}

PUTCHAR_PROTOTYPE
{
  USART_SendData(USART3, (uint8_t) ch);
  while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET)
  {}

  return ch;
}


