#include "tim.h"

volatile uint32_t gTimerDrvTicks = 0;

uint32_t TimerDrvGetTicks()
{
  uint32_t ticks;
  ticks = gTimerDrvTicks;
  return ticks;
}

uint8_t TimerDrvGetDly(uint32_t TicksHome, uint32_t TicksDly)
{
  uint32_t ticks;
  ticks = TimerDrvGetTicks();
  if(ticks >= TicksHome)
  {
    if((ticks - TicksHome) >= TicksDly)
    {
      return 1;    //��ʱ��
    }
    return 0;      //û��ʱ
  }
  if((ticks + 0xffffffff - TicksHome + 1) >= TicksDly)
  {
    return 1;
  }
  return 0;
}
