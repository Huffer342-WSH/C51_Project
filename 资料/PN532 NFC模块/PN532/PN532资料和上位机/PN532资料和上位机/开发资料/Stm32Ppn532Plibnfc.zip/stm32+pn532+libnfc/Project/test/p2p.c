#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stm32f10x.h>
#include <nfc/nfc.h>

extern nfc_emdev emdev;

void initiator()
{
  nfc_device* pnd;
  nfc_target nt;
  uint8_t  abtRx[264];
  uint8_t  abtTx[] = "Hello! My name is Li Lei, what's your name?";
  pnd = nfc_open(&emdev);
  if(NULL==pnd)
  {
    printf( "[APP ERROR]Fail to open PN532\n");
    return;
  }
  if (nfc_initiator_init(pnd) < 0) {
    printf( "[APP ERROR]nfc_initiator_init\n");
    nfc_close(pnd);
    return;
  }

  if (nfc_initiator_select_dep_target(pnd, NDM_PASSIVE, NBR_212, NULL, &nt, 10000) < 0) {
    printf( "[APP ERROR]nfc_initiator_select_dep_target\n");
    nfc_close(pnd);
    return;
  }
  //print_nfc_target(&nt, false);

  printf("[APP]Sending: %s\n", abtTx);
  int res;
  if ((res = nfc_initiator_transceive_bytes(pnd, abtTx, sizeof(abtTx), abtRx, sizeof(abtRx), 500)) < 0) {
    printf( "[APP ERROR]nfc_initiator_transceive_bytes\n");
    nfc_close(pnd);
    return;
  }

  abtRx[res] = 0;
  printf("[APP]Received: %s\n", abtRx);

  if (nfc_initiator_deselect_target(pnd) < 0) {
    printf( "[APP ERROR]nfc_initiator_deselect_target\n");
    nfc_close(pnd);
    return;
  }

  nfc_close(pnd);
}

void target()
{
  nfc_device* pnd;
  uint8_t  abtRx[264];
  int  szRx;
  uint8_t  abtTx[] = "Hello, my name is Han Meimei!";

  nfc_target nt = {
    .nm = {
      .nmt = NMT_DEP,
      .nbr = NBR_UNDEFINED
    },
    .nti = {
      .ndi = {
        .abtNFCID3 = { 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xff, 0x00, 0x00 },
        .szGB = 4,
        .abtGB = { 0x12, 0x34, 0x56, 0x78 },
        .ndm = NDM_UNDEFINED,
        /* These bytes are not used by nfc_target_init: the chip will provide them automatically to the initiator */
        .btDID = 0x00,
        .btBS = 0x00,
        .btBR = 0x00,
        .btTO = 0x00,
        .btPP = 0x01,
      },
    },
  };

  pnd = nfc_open(&emdev);
  if (pnd == NULL) {
    printf("[APP ERROR]Unable to open NFC device.\n");
    return;
  }

  printf("Waiting for initiator request...\n");
  if ((szRx = nfc_target_init(pnd, &nt, abtRx, sizeof(abtRx), 10000)) < 0) {
    printf( "[APP ERROR]nfc_target_init");
    nfc_close(pnd);
    return;
  }

  printf("Initiator request received. Waiting for data...\n");
  if ((szRx = nfc_target_receive_bytes(pnd, abtRx, sizeof(abtRx), 500)) < 0) {
    printf( "[APP ERROR]nfc_target_receive_bytes\n");
    nfc_close(pnd);
    return;
  }
  abtRx[(size_t) szRx] = '\0';
  printf("[APP]Received: %s\n", abtRx);

  printf("[APP]Sending: %s\n", abtTx);
  
  if (nfc_target_send_bytes(pnd, abtTx, sizeof(abtTx), 0) < 0) {
    printf( "[APP ERROR]nfc_target_send_bytes\n");
    nfc_close(pnd);
    return;
  }
  printf("Data sent.\n");

  nfc_close(pnd);
 }



