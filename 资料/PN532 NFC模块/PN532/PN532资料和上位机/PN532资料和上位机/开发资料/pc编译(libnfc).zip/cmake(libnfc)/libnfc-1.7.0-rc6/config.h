#include "contrib/windows.h"

#define PACKAGE_NAME "libnfc"
#define PACKAGE_VERSION "1.7.0"
#define PACKAGE_STRING "libnfc 1.7.0"
#define LIBNFC_SYSCONFDIR "C:/Program Files (x86)/libnfc/config"
